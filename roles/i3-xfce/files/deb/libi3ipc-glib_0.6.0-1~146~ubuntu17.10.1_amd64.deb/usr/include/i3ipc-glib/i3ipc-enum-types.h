
/* Generated data (by glib-mkenums) */

#ifndef __I3IPC_ENUM_TYPES_H__
#define __I3IPC_ENUM_TYPES_H__

#include <glib-object.h>
/* enumerations from "../i3ipc-glib/i3ipc-event-types.h" */
GType i3ipc_event_get_type (void) G_GNUC_CONST;
#define I3IPC_TYPE_EVENT (i3ipc_event_get_type())
/* enumerations from "../i3ipc-glib/i3ipc-reply-types.h" */
GType i3ipc_reply_type_get_type (void) G_GNUC_CONST;
#define I3IPC_TYPE_REPLY_TYPE (i3ipc_reply_type_get_type())
/* enumerations from "../i3ipc-glib/i3ipc-connection.h" */
GType i3ipc_message_type_get_type (void) G_GNUC_CONST;
#define I3IPC_TYPE_MESSAGE_TYPE (i3ipc_message_type_get_type())

#endif /* !__I3IPC_ENUM_TYPES_H__ */

/* Generated data ends here */

